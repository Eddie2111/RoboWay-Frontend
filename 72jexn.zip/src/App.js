import React from "react";
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from "react-responsive-carousel";
export default function App() {
  return (
    <>
      <p> This is carousel </p>

      <Carousel
        autoPlay={true}
        infiniteLoop={true}
        showArrows={false}
        stopOnHover={true}
        swipeable={true}
      >
        <div>
          <img src="./elephant.jpg" alt="AI" />
          <p className="legend">Elephant</p>
        </div>
        <div>
          <img src="./game.jpg" alt="AI" />
          <p className="legend">game 1</p>
        </div>
        <div>
          <img src="./game2.jpg" alt="AI" />
          <p className="legend">game 2</p>
        </div>
      </Carousel>
    </>
  );
}
